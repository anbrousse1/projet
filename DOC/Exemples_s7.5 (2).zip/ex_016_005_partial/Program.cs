﻿// ========================================================================
//
// Copyright (C) 2013-2014 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2014-03-30
// Mise à jour   : 2016-09-26
//
// ========================================================================

using static System.Console;

namespace ex_016_005_partial
{
    class Program
    {
        static void Main(string[] args)
        {
            MaClasse c = new MaClasse();
            c.N1 = 1;
            c.N2 = 2;
            c.N3 = 3;
            WriteLine(c);
        }
    }
}
