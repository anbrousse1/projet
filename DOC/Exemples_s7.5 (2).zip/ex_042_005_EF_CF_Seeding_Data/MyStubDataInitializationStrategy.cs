﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : MyStubDataInitializationStrategy.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-17
//
// ========================================================================

using System;
using System.Data.Entity;

namespace ex_042_005_EF_CF_Seeding_Data
{
    /// <summary>
    /// classe personnalisée pour l'initialisation de la base :
    /// - recrée une base neuve (dérive de DropCreateDatabaseAlways
    /// - introduit des données stubbées (méthode Seed)
    /// </summary>
    class MyStubDataInitializationStrategy : DropCreateDatabaseAlways<NounoursDBEntities>
    {
        protected override void Seed(NounoursDBEntities context)
        {
            Nounours chewie = new Nounours { Nom = "Chewbacca", DateDeNaissance = new DateTime(1977, 5, 27), NbPoils = 1234567 };
            Nounours yoda = new Nounours { Nom = "Yoda", DateDeNaissance = new DateTime(1980, 5, 21), NbPoils = 3 };
            Nounours ewok = new Nounours { Nom = "Ewok", DateDeNaissance = new DateTime(1983, 5, 25), NbPoils = 3456789 };

            context.NounoursSet.AddRange(new Nounours[] { chewie, yoda, ewok });

            base.Seed(context);
        }
    }
}
