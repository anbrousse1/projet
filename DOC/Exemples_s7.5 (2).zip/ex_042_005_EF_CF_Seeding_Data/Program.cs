﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-17
//
// ========================================================================

using System;
using System.IO;
using static System.Console;
using System.Linq;

namespace ex_042_005_EF_CF_Seeding_Data
{
    /// <summary>
    /// Cet exemple présente les différentes stratégies d'initialisation de la base de données.
    /// Dans les exemples précédents, vous avez pu constater que si la base n'existe pas, elle est automatiquement créée.
    /// Si elle existe, elle est utilisée telle quelle.
    /// Ceci est le comportement par défaut, mais il existe d'autres stratégies d'initialisation.
    /// 
    /// Cet exemple reprend le 042_004 tout en modifiant la stratégie d'initialisation DropCreateDatabaseAlways et en l'injectant pour créer des données stubbées.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.SetData("DataDirectory", Directory.GetCurrentDirectory());

            Nounours roudoudou = new Nounours { Nom = "Roudoudou", DateDeNaissance = new DateTime(2015, 8, 15), NbPoils = 2000 };
            Nounours routoupete = new Nounours { Nom = "Routoupete", DateDeNaissance = new DateTime(2016, 9, 16), NbPoils = 1000 };

            //création du DbContext et injection de la dépendance à MyStubDataInitializationStrategy
            using (NounoursDBEntities db = new NounoursDBEntities(new MyStubDataInitializationStrategy()))
            {
                if (db.NounoursSet.Count() > 0)
                {
                    WriteLine("La base n'est pas vide !");
                    foreach (var n in db.NounoursSet)
                    {
                        WriteLine($"\t{n}");
                    }
                }

                db.NounoursSet.AddRange(new Nounours[] { roudoudou, routoupete });

                db.SaveChanges();
                WriteLine("Base après ajout des 2 nounours et sauvegarde des changements :");
                foreach (var n in db.NounoursSet)
                {
                    WriteLine($"\t{n}");
                }
            }
        }
    }
}
