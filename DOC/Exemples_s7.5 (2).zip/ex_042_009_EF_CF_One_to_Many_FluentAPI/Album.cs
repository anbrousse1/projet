﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Album.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-19
//
// ========================================================================


using System;
using System.Collections.Generic;

namespace ex_042_009_EF_CF_One_to_Many_FluentAPI
{
    /// <summary>
    /// Album est une classe POCO, i.e. Plain Old CLR Object.
    /// Elle a une relation 1-many avec la classe Morceau via la propriété Morceaux.
    /// </summary>
    class Album
    {
        public Guid UniqueId
        {
            get; set;
        }

        public string Titre
        {
            get; set;
        }

        public DateTime DateDeSortie
        {
            get; set;
        }

        public virtual ICollection<Morceau> Morceaux { get; set; } = new List<Morceau>();
    }
}
