﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Morceau.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-19
//
// ========================================================================

using System;

namespace ex_042_009_EF_CF_One_to_Many_FluentAPI
{
    /// <summary>
    /// Morceau est une classe POCO, i.e. Plain Old CLR Object.
    /// Elle a une relation 1-many avec la classe Morceau via la propriété Album.
    /// 
    /// La propriété MorceauId pourrait servir de clé étrangère dans l'alternative présentée en commentaire dans AlbumDBEntities
    /// </summary>
    class Morceau
    {
        public Guid UniqueId
        {
            get; set;
        }

       // public Guid MorceauId { get; set; }

        public string Titre
        {
            get; set;
        }

        public virtual Album Album
        {
            get; set; 
        }
    }
}
