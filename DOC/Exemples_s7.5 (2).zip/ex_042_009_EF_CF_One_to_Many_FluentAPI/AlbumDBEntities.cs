﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : AlbumDBEntities.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-19
//
// ========================================================================

using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace ex_042_009_EF_CF_One_to_Many_FluentAPI
{
    /// <summary>
    /// La classe qui dérive de DbContext est celle qui permettra de faire les opérations CRUD sur le modèle.
    /// Cette classe contient deux DbSet<T> pour permettre de réaliser des opérations CRUD sur les types T, ici Album et Morceau.
    /// 
    /// Dans cet exemple, nous avons créé notre propre stratégie d'initialisation qui recrée la base à chaque fois et en plus, lui ajoute des données stubbées.
    /// Pour cette raison, nous avons ajouté un constructeur qui prend un IDatabaseInitializer en paramètre pour pouvoir injecter la stratégie d'initialisation.
    /// </summary>
    class AlbumDBEntities : DbContext
    {
        public AlbumDBEntities(IDatabaseInitializer<AlbumDBEntities> databaseInitializer) : base("name=AlbumDBContext")
        {
            //permet de modifier la stratégie d'initialisation pour que la base de données soit recréée à chaque fois et avec des données stubbées (cf. lors de la création dans Program)
            Database.SetInitializer<AlbumDBEntities>(databaseInitializer);
        }
        public virtual DbSet<Album> Albums { get; set; }
        public virtual DbSet<Morceau> Morceaux { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //création de la table Albums
            modelBuilder.Entity<Album>().ToTable("Albums"); //nom de la table
            modelBuilder.Entity<Album>().HasKey(a => a.UniqueId); //définition de la clé primaire
            modelBuilder.Entity<Album>().Property(a => a.UniqueId)
                                           .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity); //définition du mode de génération de la clé : génération à l'insertion

            //création de la table "Carnets"
            modelBuilder.Entity<Morceau>().ToTable("Morceaux"); // nom de la table
            modelBuilder.Entity<Morceau>().HasKey(m => m.UniqueId); //définition de la clé primaire
            modelBuilder.Entity<Morceau>().Property(m => m.UniqueId)
                                                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity); // définition du mode de génération de la clé : pas de génération automatique


            //on précise qu'il y a une relation entre Album et Morceau
            modelBuilder.Entity<Album>().HasMany(a => a.Morceaux) //on dit que l'Album a plusieurs Morceaux
                                        .WithRequired(m => m.Album); // et que chaque Morceau a un Album
            //Si vous regardez la table obtenue, vous pouvez voir qu'Entity Framework a automatiquement généré une clé étrangère.
            //Vous pouvez également ajouter vous-mêmes une clé étrangère (MorceauId par exemple dans Morceau) et le préciser à Entity Framework, comme dans l'exemple ci-dessous.
            /*  modelBuilder.Entity<Morceau>() //l'entité Morceau...
                          .HasRequired<Album>(m => m.Album) //a une propriété obligatoire Album...
                          .WithMany(a => a.Morceaux).HasForeignKey(m => m.MorceauId); //reliée à la propriété Morceaux de l'Album...*/

            base.OnModelCreating(modelBuilder);
        }
    }
}
