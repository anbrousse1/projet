﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : AlbumArtisteDBEntities.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-22
//
// ========================================================================

using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace ex_042_011_EF_CF_Many_to_Many_FluentAPI
{
    /// <summary>
    /// La classe qui dérive de DbContext est celle qui permettra de faire les opérations CRUD sur le modèle.
    /// Cette classe contient deux DbSet<T> pour permettre de réaliser des opérations CRUD sur les types T, ici Album et Artiste.
    /// 
    /// Dans cet exemple, nous avons créé notre propre stratégie d'initialisation qui recrée la base à chaque fois et en plus, lui ajoute des données stubbées.
    /// Pour cette raison, nous avons ajouté un constructeur qui prend un IDatabaseInitializer en paramètre pour pouvoir injecter la stratégie d'initialisation.
    /// </summary>
    class AlbumArtisteDBEntities : DbContext
    {
        public AlbumArtisteDBEntities(IDatabaseInitializer<AlbumArtisteDBEntities> databaseInitializer) : base("name=AlbumArtisteDBContext")
        {
            //permet de modifier la stratégie d'initialisation pour que la base de données soit recréée à chaque fois et avec des données stubbées (cf. lors de la création dans Program)
            Database.SetInitializer<AlbumArtisteDBEntities>(databaseInitializer);
        }
        public virtual DbSet<Album> Albums { get; set; }
        public virtual DbSet<Artiste> Artistes { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //création de la table Albums
            modelBuilder.Entity<Album>().ToTable("Albums"); //nom de la table
            modelBuilder.Entity<Album>().HasKey(a => a.UniqueId); //définition de la clé primaire
            modelBuilder.Entity<Album>().Property(a => a.UniqueId)
                                           .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity); //définition du mode de génération de la clé : génération à l'insertion

            //création de la table Artistes
            modelBuilder.Entity<Artiste>().ToTable("Artistes"); //nom de la table
            modelBuilder.Entity<Artiste>().HasKey(a => a.UniqueId); //définition de la clé primaire
            modelBuilder.Entity<Artiste>().Property(a => a.UniqueId)
                                           .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity); //définition du mode de génération de la clé : génération à l'insertion


            //on précise qu'il y a une relation entre Album et Artiste
            modelBuilder.Entity<Album>().HasMany(album => album.Artistes) //on dit que l'Album a plusieurs Artistes
                                        .WithMany(artiste => artiste.Albums) // et que chaque Artiste a un Album
                                        .Map(ca =>
                                        {
                                            ca.MapLeftKey("AlbumID");
                                            ca.MapRightKey("ArtisteID");
                                            ca.ToTable("AlbumsArtistes");
                                        });

            base.OnModelCreating(modelBuilder);
        }
    }
}
