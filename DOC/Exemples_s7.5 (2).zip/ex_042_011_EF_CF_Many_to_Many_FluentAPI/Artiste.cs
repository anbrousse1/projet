﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Artiste.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-22
//
// ========================================================================


using System;
using System.Collections.Generic;

namespace ex_042_011_EF_CF_Many_to_Many_FluentAPI
{
    /// <summary>
    /// Artiste est une classe POCO, i.e. Plain Old CLR Object.
    /// Elle a une relation 1-many avec la classe Morceau via la propriété Morceaux.
    /// La clé primaire est générée lors de l'insertion en table.
    /// Elle contient une collection d'Albums
    /// </summary>
    class Artiste
    {
        public Guid UniqueId
        {
            get; set;
        }

        public string Prénom
        {
            get; set;
        }
        public string Nom
        {
            get; set;
        }

        public DateTime DateDeNaissance
        {
            get; set;
        }

        public DateTime? DateDeMort
        {
            get; set;
        }

        public ICollection<Album> Albums { get; set; } = new List<Album>();
    }
}
