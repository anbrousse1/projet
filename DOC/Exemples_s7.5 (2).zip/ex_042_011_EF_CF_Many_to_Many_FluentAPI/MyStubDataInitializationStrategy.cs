﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : MyStubDataInitializationStrategy.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-22
//
// ========================================================================

using System;
using System.Collections.Generic;
using System.Data.Entity;

namespace ex_042_011_EF_CF_Many_to_Many_FluentAPI
{
    /// <summary>
    /// classe personnalisée pour l'initialisation de la base :
    /// - recrée une base neuve (dérive de DropCreateDatabaseAlways)
    /// - introduit des données stubbées (méthode Seed)
    /// </summary>
    class MyStubDataInitializationStrategy : DropCreateDatabaseAlways<AlbumArtisteDBEntities>
    {
        protected override void Seed(AlbumArtisteDBEntities context)
        {
            Dictionary<string, Album> albums = new Dictionary<string, Album>()
            {
                ["kindOfBlue"] = new Album { Titre = "Kind of Blue", DateDeSortie = new DateTime(1959, 8, 17) },
                ["somethinElse"] = new Album { Titre = "Somethin' Else", DateDeSortie = new DateTime(1958, 8, 1) }
            };
            Dictionary<string, Artiste> artistes = new Dictionary<string, Artiste>()
            {
                ["milesDavis"] = new Artiste { Prénom = "Miles", Nom = "Davis", DateDeNaissance = new DateTime(1926, 5, 26), DateDeMort = new DateTime(1991, 9, 28) },
                ["johnColtrane"] = new Artiste { Prénom = "John", Nom = "Coltrane", DateDeNaissance = new DateTime(1926, 9, 23), DateDeMort = new DateTime(1967, 7, 11) },
                ["julianAdderley"] = new Artiste { Prénom = "Julian", Nom = "Adderley", DateDeNaissance = new DateTime(1928, 9, 15), DateDeMort = new DateTime(1975, 8, 8) },
                ["billEvans"] = new Artiste { Prénom = "Bill", Nom = "Evans", DateDeNaissance = new DateTime(1929, 8, 16), DateDeMort = new DateTime(1980, 9, 15) },
                ["wyntonKelly"] = new Artiste { Prénom = "Wynton", Nom = "Kelly", DateDeNaissance= new DateTime(1931, 12, 2), DateDeMort=new DateTime(1971, 4, 12)},
                ["paulChambers"] = new Artiste { Prénom = "Paul", Nom = "Chambers", DateDeNaissance= new DateTime(1935, 4, 22), DateDeMort=new DateTime(1969, 1, 4)},
                ["jimmyCobb"] = new Artiste { Prénom = "Jimmy", Nom = "Cobb", DateDeNaissance= new DateTime(1929, 1, 20)},
                ["hankJones"] = new Artiste { Prénom = "Hank", Nom = "Jones", DateDeNaissance= new DateTime(1918, 7, 31), DateDeMort= new DateTime(2010, 5, 16)},
                ["samJones"] = new Artiste { Prénom = "Sam", Nom = "Jones", DateDeNaissance= new DateTime(1924, 11, 12), DateDeMort=new DateTime(1981, 12, 15)},
                ["artBlakey"] = new Artiste { Prénom = "Art", Nom = "Blakey", DateDeNaissance= new DateTime(1919, 10, 11), DateDeMort = new DateTime(1990, 10, 16)}
            };

            //les artistes qui jouent sur Kind Of Blue sont reliés à l'album
            albums["kindOfBlue"].Artistes.Add(artistes["milesDavis"]);
            albums["kindOfBlue"].Artistes.Add(artistes["johnColtrane"]);
            albums["kindOfBlue"].Artistes.Add(artistes["julianAdderley"]);
            albums["kindOfBlue"].Artistes.Add(artistes["billEvans"]);
            albums["kindOfBlue"].Artistes.Add(artistes["wyntonKelly"]);
            albums["kindOfBlue"].Artistes.Add(artistes["paulChambers"]);
            albums["kindOfBlue"].Artistes.Add(artistes["jimmyCobb"]);

            artistes["milesDavis"].Albums.Add(albums["kindOfBlue"]);
            artistes["johnColtrane"].Albums.Add(albums["kindOfBlue"]);
            artistes["julianAdderley"].Albums.Add(albums["kindOfBlue"]);
            artistes["billEvans"].Albums.Add(albums["kindOfBlue"]);
            artistes["wyntonKelly"].Albums.Add(albums["kindOfBlue"]);
            artistes["paulChambers"].Albums.Add(albums["kindOfBlue"]);
            artistes["jimmyCobb"].Albums.Add(albums["kindOfBlue"]);

            //les artistes qui jouent sur Somethin' Else sont reliés à l'album

            albums["somethinElse"].Artistes.Add(artistes["julianAdderley"]);
            albums["somethinElse"].Artistes.Add(artistes["milesDavis"]);
            albums["somethinElse"].Artistes.Add(artistes["hankJones"]);
            albums["somethinElse"].Artistes.Add(artistes["samJones"]);
            albums["somethinElse"].Artistes.Add(artistes["artBlakey"]);

            artistes["julianAdderley"].Albums.Add(albums["somethinElse"]);
            artistes["milesDavis"].Albums.Add(albums["somethinElse"]);
            artistes["hankJones"].Albums.Add(albums["somethinElse"]);
            artistes["samJones"].Albums.Add(albums["somethinElse"]);
            artistes["artBlakey"].Albums.Add(albums["somethinElse"]);


            context.Albums.AddRange(albums.Values);
            context.Artistes.AddRange(artistes.Values);

            base.Seed(context);
        }
    }
}
