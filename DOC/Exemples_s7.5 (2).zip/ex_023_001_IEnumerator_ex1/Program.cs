﻿// ========================================================================
//
// Copyright (C) 2013-2014 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2014-03-30
// Mise à jour   : 2016-09-27
//
// ========================================================================

using static System.Console;

namespace ex_023_001_IEnumerator_ex1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tab = { 1, 2, 3 };
            System.Collections.IEnumerator etor = tab.GetEnumerator();

            while (etor.MoveNext())
            {
                int a = (int)etor.Current;
                WriteLine(a);
            }

            WriteLine("ou");

            foreach (int a in tab)
            {
                WriteLine(a);
            }

            //2ème exemple
            string s = "Bonjour";
            System.Collections.IEnumerator str_etor = s.GetEnumerator();
            while (str_etor.MoveNext())
            {
                Write($"{str_etor.Current}.");
            }
        }
    }
}
