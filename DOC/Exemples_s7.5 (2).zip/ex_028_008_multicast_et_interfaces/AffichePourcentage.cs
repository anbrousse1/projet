﻿// ========================================================================
//
// Copyright (C) 2013-2014 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : AffichePourcentage.cs
// Author        : Marc Chevaldonné
// Creation date : 2014-04-27
// Mise à jour   : 2016-10-03
//
// ========================================================================

using static System.Console;

namespace ex_028_008_multicast_et_interfaces
{
    class AffichePourcentage : IProgression
    {
        public int Progression
        {
            set
            {
                WriteLine($"{value}%...");
            }
        }
    }
}
