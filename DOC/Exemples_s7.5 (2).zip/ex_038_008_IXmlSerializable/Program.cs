﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-08
//
// ========================================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using static System.Console;

namespace ex_038_008_IXmlSerializable
{
    class Program
    {
        static void Main(string[] args)
        {
            Directory.SetCurrentDirectory(Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).FullName, "ex_038_008_IXmlSerializable", "XML"));

            Artiste bojan = new Artiste { Prénom = "Bojan", Nom = "Z", Naissance = new DateTime(1968, 2, 2), Instrument = "Piano" };
            Album duo = new Album { Titre = "Duo", AnnéeDeSortie = 2015, Artiste = bojan };

            using (XmlWriter writer = XmlWriter.Create("album.xml"))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("album", "");
                duo.WriteXml(writer);
                writer.WriteEndElement();
                writer.WriteEndDocument();
            }

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;
            settings.IgnoreProcessingInstructions = true;

            using (XmlReader reader = XmlReader.Create("album.xml", settings))
            {
                while(reader.NodeType != XmlNodeType.Element) reader.Read();
                Album a = new Album(reader);
                WriteLine(a);
            }
        }
    }
}
