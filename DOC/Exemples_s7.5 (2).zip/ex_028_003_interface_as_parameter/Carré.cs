﻿// ========================================================================
//
// Copyright (C) 2013-2014 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Carré.cs
// Author        : Marc Chevaldonné
// Creation date : 2014-04-27
//
// ========================================================================

namespace ex_028_003_interface_as_parameter
{
    class Carré : IModifieur
    {
        public int Modifier(int nombreAModifier)
        {
            return nombreAModifier * nombreAModifier;
        }
    }
}
