﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : AlbumArtisteDBEntities.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-21
//
// ========================================================================

using System.Data.Entity;

namespace ex_042_010_EF_CF_Many_to_Many
{
    /// <summary>
    /// La classe qui dérive de DbContext est celle qui permettra de faire les opérations CRUD sur le modèle.
    /// Cette classe contient deux DbSet<T> pour permettre de réaliser des opérations CRUD sur les types T, ici Album et Artiste.
    /// 
    /// Dans cet exemple, nous avons créé notre propre stratégie d'initialisation qui recrée la base à chaque fois et en plus, lui ajoute des données stubbées.
    /// Pour cette raison, nous avons ajouté un constructeur qui prend un IDatabaseInitializer en paramètre pour pouvoir injecter la stratégie d'initialisation.
    /// </summary>
    class AlbumArtisteDBEntities : DbContext
    {
        public AlbumArtisteDBEntities(IDatabaseInitializer<AlbumArtisteDBEntities> databaseInitializer) : base("name=AlbumArtisteDBContext")
        {
            //permet de modifier la stratégie d'initialisation pour que la base de données soit recréée à chaque fois et avec des données stubbées (cf. lors de la création dans Program)
            Database.SetInitializer<AlbumArtisteDBEntities>(databaseInitializer);
        }
        public virtual DbSet<Album> Albums { get; set; }
        public virtual DbSet<Artiste> Artistes { get; set; }
    }
}
