﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : NounoursDBEntities.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-12
//
// ========================================================================

using System.Data.Entity;

namespace ex_042_002_EF_CodeFirst_data_annotations
{
    /// <summary>
    /// La classe qui dérive de DbContext est celle qui permettra de faire les opérations CRUD sur le modèle.
    /// Cette classe contient un DbSet<T> pour permettre de réaliser des opérations CRUD sur le type T, ici Nounours.
    /// 
    /// Lorsque nous utiliserons cette classe, le programme cherchera la chaîne de connection (connectionString) avec le même nom que celui passé
    ///  dans le constructeur de DbContext (ici NounoursDBContext). Il cherche la connectionString à différents endroits et en particulier ici 
    ///  dans App.config.
    /// Si cette table n'existe pas, il va la créer automatiquement. Ceci est configurable et sera présenté dans les exemples suivants.
    /// </summary>
    class NounoursDBEntities : DbContext
    {
        public NounoursDBEntities() : base("name=NounoursDBContext")
        { }
        public virtual DbSet<Nounours> NounoursSet { get; set; }
    }
}
