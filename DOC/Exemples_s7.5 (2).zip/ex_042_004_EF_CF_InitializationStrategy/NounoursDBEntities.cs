﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : NounoursDBEntities.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-17
//
// ========================================================================

using System.Data.Entity;

namespace ex_042_004_EF_CF_InitializationStrategy
{
    /// <summary>
    /// La classe qui dérive de DbContext est celle qui permettra de faire les opérations CRUD sur le modèle.
    /// Cette classe contient un DbSet<T> pour permettre de réaliser des opérations CRUD sur le type T, ici Nounours.
    /// 
    /// Par défaut, Entityt Framework utilise une stratégie d'initialisation qui crée la base de données par défaut si elle n'existe pas, mais pas si elle existe déjà.
    /// Il existe d'autres stratégies d'initialisation et on peut les choisir avec la méthode Database.SetInitializer.
    /// </summary>
    class NounoursDBEntities : DbContext
    {
        public NounoursDBEntities() : base("name=NounoursDBContext")
        {
            //permet de modifier la stratégie d'initialisation pour que la base de données soit changée à chaque fois que le modèle change
            //modifier les propriétés de Nounours pour vous en rendre compte (par exemple, changez la propriété UniqueId en int puis Guid...)
            //Ce mode est très pratique en mode développement tant que le modèle n'est pas complètement sûr.
            Database.SetInitializer<NounoursDBEntities>(new DropCreateDatabaseIfModelChanges<NounoursDBEntities>());

            //autre stratégie d'intialisation à tester : recrée à chaque fois la base de données
            //Database.SetInitializer<NounoursDBEntities>(new DropCreateDatabaseAlways<NounoursDBEntities>());
        }
        public virtual DbSet<Nounours> NounoursSet { get; set; }
    }
}
