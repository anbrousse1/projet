﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-17
//
// ========================================================================

using System;
using System.IO;
using static System.Console;
using System.Linq;

namespace ex_042_004_EF_CF_InitializationStrategy
{
    /// <summary>
    /// Cet exemple présente les différentes stratégies d'initialisation de la base de données.
    /// Dans les exemples précédents, vous avez pu constater que si la base n'existe pas, elle est automatiquement créée.
    /// Si elle existe, elle est utilisée telle quelle.
    /// Ceci est le comportement par défaut, mais il existe d'autres stratégies d'initialisation.
    /// 
    /// Cet exemple reprend le 042_002 tout en modifiant les stratégies d'initialisation dans la classe NounoursDBEntities (cf. commentaires).
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.SetData("DataDirectory", Directory.GetCurrentDirectory());

            Nounours chewie = new Nounours { Nom = "Chewbacca", DateDeNaissance = new DateTime(1977, 5, 27), NbPoils = 1234567 };
            Nounours yoda = new Nounours { Nom = "Yoda", DateDeNaissance = new DateTime(1980, 5, 21), NbPoils = 3 };
            Nounours ewok = new Nounours { Nom = "Ewok", DateDeNaissance = new DateTime(1983, 5, 25), NbPoils = 3456789 };

            using (NounoursDBEntities db = new NounoursDBEntities())
            {
                if (db.NounoursSet.Count() > 0)
                {
                    WriteLine("La base n'est pas vide !");
                    foreach (var n in db.NounoursSet)
                    {
                        WriteLine($"\t{n}");
                    }
                    WriteLine("début du nettoyage...");
                }
                foreach (var n in db.NounoursSet.ToArray())
                {
                    WriteLine($"Suppression de {n}");
                    db.NounoursSet.Remove(n);
                }

                WriteLine("Base avant sauvegarde des changements :");
                foreach (var n in db.NounoursSet)
                {
                    WriteLine($"\t{n}");
                }
                db.SaveChanges();
                WriteLine("Base après sauvegarde des changements :");
                foreach (var n in db.NounoursSet)
                {
                    WriteLine($"\t{n}");
                }

                db.NounoursSet.AddRange(new Nounours[] { chewie, yoda, ewok });

                db.SaveChanges();
                WriteLine("Base après ajout des 3 nounours et sauvegarde des changements :");
                foreach (var n in db.NounoursSet)
                {
                    WriteLine($"\t{n}");
                }
            }
        }
    }
}
