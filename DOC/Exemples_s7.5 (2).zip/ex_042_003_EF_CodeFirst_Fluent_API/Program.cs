﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-16
//
// ========================================================================

using System;
using System.IO;
using static System.Console;
using System.Linq;

namespace ex_042_003_EF_CodeFirst_Fluent_API
{
    /// <summary>
    /// Ce troisième exemple utilisant l'approche CodeFirst avec EntityFramework montre comment vous pouvez créer simplement
    /// une base à partir de vos classes métier, en profitant de l'API Fluent d'Entity Framework.
    /// 
    /// Elle est définie dans le fichier App.config avec le nom NounoursDBContext.
    /// Plus d'explications sur la chaîne de connection sont données dans App.config.
    /// 
    /// Nous allons nous attarder sur la classe Nounours et NounoursDBEntities.
    /// 1/ Nounours -> voir commentaires dans la classe Nounours 
    /// 2/ NounoursDBEntities -> voir commentaires dans la classe NounoursDBEntities
    /// C'est cette classe NounoursDBEntities qui explique comment traduire Nounours en Table.
    /// 
    /// Ensuite, nous pouvons donc instancier NounoursDBEntities (à l'aide d'un bloc using car il s'agit d'une ressource non managée).
    /// Celle-ci donne accès à la DbSet<Nounours> à laquelle nous rajoutons 3 Nounours.
    /// 
    /// Ces modifications sont persistées dans la base lors de l'appel à SaveChanges.
    /// 
    /// Pour visualiser les résultats, vous pouvez :
    /// - aller dans Affichage -> Explorateur d'objets SQL Server
    /// - dans cet explorateur, SQL Server -> (localdb)\MSSQLLocalDB... -> Bases de données 
    ///     -> ex_042_003_EF_CodeFirst_Fluent_API -> Tables -> dbo.TableNounours
    ///     en cliquant sur dbo.TableNounours vous pourrez voir la table
    ///     avec un clic droit -> "Afficher les données" sur dbo.Nounours vous pourrez voir les données dans la table
    ///     
    /// Si vous exécutez une deuxième fois le projet après avoir modifié la classe Nounours, celui-ci ne marchera pas 
    /// car la table créée n'aura plus les bonnes caractéristiques correspondant à la classe Nounours.
    /// Vous pouvez pour cela effacer la base, avec un clic droit sur ex_042_003_EF_CodeFirst_Fluent_API -> Supprimer
    ///  puis relancer le programme.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.SetData("DataDirectory", Directory.GetCurrentDirectory());

            Nounours chewie = new Nounours { Nom = "Chewbacca", DateDeNaissance = new DateTime(1977, 5, 27), NbPoils = 1234567 };
            Nounours yoda = new Nounours { Nom = "Yoda", DateDeNaissance = new DateTime(1980, 5, 21), NbPoils = 3 };
            Nounours ewok = new Nounours { Nom = "Ewok", DateDeNaissance = new DateTime(1983, 5, 25), NbPoils = 3456789 };

            using (NounoursDBEntities db = new NounoursDBEntities())
            {
                if (db.NounoursSet.Count() > 0)
                {
                    WriteLine("La base n'est pas vide !");
                    foreach (var n in db.NounoursSet)
                    {
                        WriteLine($"\t{n}");
                    }
                    WriteLine("début du nettoyage...");
                }
                foreach (var n in db.NounoursSet.ToArray())
                {
                    WriteLine($"Suppression de {n}");
                    db.NounoursSet.Remove(n);
                }

                WriteLine("Base avant sauvegarde des changements :");
                foreach (var n in db.NounoursSet)
                {
                    WriteLine($"\t{n}");
                }
                db.SaveChanges();
                WriteLine("Base après sauvegarde des changements :");
                foreach (var n in db.NounoursSet)
                {
                    WriteLine($"\t{n}");
                }

                db.NounoursSet.AddRange(new Nounours[] { chewie, yoda, ewok });

                db.SaveChanges();
                WriteLine("Base après ajout des 3 nounours et sauvegarde des changements :");
                foreach (var n in db.NounoursSet)
                {
                    WriteLine($"\t{n}");
                }
            }
        }
    }
}
