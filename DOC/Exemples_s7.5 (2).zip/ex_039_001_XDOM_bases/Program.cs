﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-05-26
// Mise à jour   : 2016-10-13
//
// ========================================================================

using System.IO;
using System.Xml.Linq;
using static System.Console;

namespace ex_039_001_XDOM_bases
{
    class Program
    {
        static void Main(string[] args)
        {
            Directory.SetCurrentDirectory(Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).FullName, "ex_039_001_XDOM_bases", "XML"));

            XDocument volcansFichier = XDocument.Load("volcans.xml");
            WriteLine(volcansFichier);

            volcansFichier.Save("volcansSave.xml");

            XElement testVolcan = XElement.Parse(
                @"<volcan activité='endormi' pays='France' type='gris'>
                    <nom>Puy de Dôme</nom>
                    <endormi_depuis>P6000Y</endormi_depuis>
                    <altitude>1465</altitude>
                    <coordonnées>
                      <latitude>45.7723</latitude>
                      <longitude>2.9658</longitude>
                    </coordonnées>
                  </volcan>");
            WriteLine(testVolcan);

            testVolcan.Save("unVolcan.xml");
        }
    }
}
