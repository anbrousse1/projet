﻿// ========================================================================
//
// Copyright (C) 2013-2014 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : VieuxNounours.cs
// Author        : Marc Chevaldonné
// Creation date : 2014-03-30
// Mise à jour   : 2016-09-29
//
// ========================================================================

namespace ex_023_011_EqualityProtocoleOnValues
{
    struct VieuxNounours
    {
        public int Id
        {
            get;
            private set;
        }

        public string Name
        {
            get;
            private set;
        }

        public VieuxNounours(int id, string name)
        {
            Id = id;
            Name = name;
        }

        //...
    }
}
