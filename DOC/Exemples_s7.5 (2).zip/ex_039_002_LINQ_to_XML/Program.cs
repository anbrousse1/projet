﻿// ========================================================================
//
// Copyright (C) 2013-2014 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2014-05-26
// Mise à jour   : 2016-10-13
//
// ========================================================================

using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using static System.Console;

namespace ex_039_002_LINQ_to_XML
{
    class Program
    {
        static void Main(string[] args)
        {
            Directory.SetCurrentDirectory(Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).FullName, "ex_039_002_LINQ_to_XML", "XML"));

            LireVolcansInXMLFile();
            WriteLine("VOLCANS LUS :");
            foreach (var volcan in listeVolcans)
            {
                WriteLine(volcan);
            }
            WriteLine("".PadRight(WindowWidth - 1, '*'));

            var pariou = new Volcan()
            {
                Nom = "Puy de Pariou",
                Altitude = 1209,
                Latitude = 45.795462f,
                Longitude = 2.970257f,
                Pays = "France",
            };
            pariou.AjouterRoches("Trachy-basalte", "trachy-andésite", "trachyte");
            listeVolcans.Add(pariou);

            WriteLine("VOLCANS APRES AJOUT :");
            foreach (var volcan in listeVolcans)
            {
                WriteLine(volcan);
            }
            WriteLine("".PadRight(WindowWidth - 1, '*'));

            EcrireVolcansInXMLFile();
        }

        static List<Volcan> listeVolcans = new List<Volcan>();

        static void LireVolcansInXMLFile()
        {
            XDocument volcansFichier = XDocument.Load("volcans.xml");

            listeVolcans = volcansFichier.Descendants("volcan")
                          .Select(eltVolcan => new Volcan()
                          {
                              Pays = eltVolcan.Attribute("pays").Value,
                              Nom = eltVolcan.Element("nom").Value,
                              Altitude = XmlConvert.ToSingle(eltVolcan.Element("altitude").Value),
                              Latitude = XmlConvert.ToSingle(eltVolcan.Element("coordonnées").Element("latitude").Value),
                              Longitude = XmlConvert.ToSingle(eltVolcan.Element("coordonnées").Element("longitude").Value)
                          }).ToList();

            foreach (var volcan in listeVolcans)
            {
                var rochesElt = volcansFichier.Descendants("volcan")
                                             .Single(elt => elt.Element("nom").Value == volcan.Nom)
                                             .Element("roches");
                if (rochesElt == null)
                {
                    continue;
                }
                volcan.AjouterRoches(rochesElt.Value.Split());
            }
        }

        private static void EcrireVolcansInXMLFile()
        {
            XDocument volcansFichier = new XDocument();

            var volcansElts = listeVolcans.Select(volcan => new XElement("volcan",
                                            new XAttribute("pays", volcan.Pays),
                                            new XElement("nom", volcan.Nom),
                                            new XElement("altitude", XmlConvert.ToString(volcan.Altitude)),
                                            new XElement("coordonnées",
                                                new XElement("latitude", XmlConvert.ToString(volcan.Latitude)),
                                                new XElement("longitude", XmlConvert.ToString(volcan.Longitude))),
                                            new XElement("roches", volcan.Roches.Count() > 0 ? volcan.Roches.Aggregate((stringRoche, nextRoche) => $"{stringRoche} {nextRoche}") : "")));

            volcansFichier.Add(new XElement("volcans", volcansElts));

            volcansFichier.Save("volcansAjout.xml");

        }
    }
}
