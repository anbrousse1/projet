﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : NounoursDBEntities.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-18
//
// ========================================================================

using System.Data.Entity;

namespace ex_042_006_EF_CF_One_to_One
{
    /// <summary>
    /// La classe qui dérive de DbContext est celle qui permettra de faire les opérations CRUD sur le modèle.
    /// Cette classe contient deux DbSet<T> pour permettre de réaliser des opérations CRUD sur les types T, ici Nounours et CarnetDeSante.
    /// 
    /// Par défaut, Entity Framework utilise une stratégie d'initialisation qui crée la base de données par défaut si elle n'existe pas, mais pas si elle existe déjà.
    /// Il existe d'autres stratégies d'initialisation et on peut les choisir avec la méthode Database.SetInitializer.
    /// 
    /// Dans cet exemple, nous avons créé notre propre stratégie d'initialisation qui recrée la base à chaque fois et en plus, lui ajoute des données stubbées.
    /// Pour cette raison, nous avons ajouté un constructeur qui prend un IDatabaseInitializer en paramètre pour pouvoir injecter la stratégie d'initialisation.
    /// </summary>
    class NounoursDBEntities : DbContext
    {
        public NounoursDBEntities(IDatabaseInitializer<NounoursDBEntities> databaseInitializer) : base("name=NounoursDBContext")
        {
            //permet de modifier la stratégie d'initialisation pour que la base de données soit recréée à chaque fois et avec des données stubbées (cf. lors de la création dans Program)
            Database.SetInitializer<NounoursDBEntities>(databaseInitializer);
        }
        public virtual DbSet<Nounours> NounoursSet { get; set; }
        public virtual DbSet<CarnetDeSante> Carnets { get; set; }
    }
}
