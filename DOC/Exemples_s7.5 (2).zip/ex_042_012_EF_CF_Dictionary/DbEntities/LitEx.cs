﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : LitEx.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-27
//
// ========================================================================

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ex_042_012_EF_CF_Dictionary
{
    /// <summary>
    /// espèce de procurateur qui enveloppe un Lit afin de permettre son lien avec Entity Framework malgré le dictionnaire
    /// </summary>
    [Table("Lits")]
    class LitEx
    {
        /// <summary>
        /// l'objet Lit wrappé (n'est pas enregistré en base)
        /// </summary>
        [NotMapped]
        public Lit Lit
        {
            get; set;
        }

        /// <summary>
        /// wrapper sur la propriété UniqueId du Lit
        /// généré lors de l'insertion en base
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid UniqueId
        {
            get { return Lit.UniqueId; }
            set { Lit.UniqueId = value; }
        }

        /// <summary>
        /// wrapper de la propriété Propriétaire du Lit
        /// </summary>
        public string Propriétaire
        {
            get { return Lit.Propriétaire; }
            set { Lit.Propriétaire = value; }
        }

        /// <summary>
        /// remplace le dictionnaire : on utilise une collection de Scores afin d'établir une relation one to many entre 
        /// LitEx et Score
        /// </summary>
        public virtual ICollection<Score> Scores
        {
            get;
            set;
        } = new List<Score>();

        public LitEx()
        {
            Lit = new Lit();
        }
    }
}
