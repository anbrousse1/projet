﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : NounoursDBEntities.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-18
//
// ========================================================================

using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace ex_042_007_EF_CF_One_to_One_FluentAPI
{
    /// <summary>
    /// La classe qui dérive de DbContext est celle qui permettra de faire les opérations CRUD sur le modèle.
    /// Cette classe contient deux DbSet<T> pour permettre de réaliser des opérations CRUD sur les types T, ici Nounours et CarnetDeSante.
    /// 
    /// Par défaut, Entity Framework utilise une stratégie d'initialisation qui crée la base de données par défaut si elle n'existe pas, mais pas si elle existe déjà.
    /// Il existe d'autres stratégies d'initialisation et on peut les choisir avec la méthode Database.SetInitializer.
    /// 
    /// Dans cet exemple, nous avons créé notre propre stratégie d'initialisation qui recrée la base à chaque fois et en plus, lui ajoute des données stubbées.
    /// Pour cette raison, nous avons ajouté un constructeur qui prend un IDatabaseInitializer en paramètre pour pouvoir injecter la stratégie d'initialisation.
    /// </summary>
    class NounoursDBEntities : DbContext
    {
        public NounoursDBEntities(IDatabaseInitializer<NounoursDBEntities> databaseInitializer) : base("name=NounoursDBContext")
        {
            //permet de modifier la stratégie d'initialisation pour que la base de données soit recréée à chaque fois et avec des données stubbées (cf. lors de la création dans Program)
            Database.SetInitializer<NounoursDBEntities>(databaseInitializer);
        }
        public virtual DbSet<Nounours> NounoursSet { get; set; }
        public virtual DbSet<CarnetDeSante> Carnets { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //création de la table TableNounours
            modelBuilder.Entity<Nounours>().ToTable("TableNounours"); //nom de la table
            modelBuilder.Entity<Nounours>().HasKey(n => n.UniqueId); //définition de la clé primaire
            modelBuilder.Entity<Nounours>().Property(n => n.UniqueId)
                                           .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity); //définition du mode de génération de la clé : génération à l'insertion
            modelBuilder.Entity<Nounours>().Property(n => n.Nom).IsRequired()
                                                                .HasMaxLength(256); //définition de la colonne Nom
            modelBuilder.Entity<Nounours>().Property(n => n.DateDeNaissance).HasColumnName("Naissance"); //changement du nom de la colonne Naissance
            //note : la colonne NbPoils n'est pas changée : utilisation des conventions EF

            //création de la table "Carnets"
            modelBuilder.Entity<CarnetDeSante>().ToTable("Carnets"); // nom de la table
            modelBuilder.Entity<CarnetDeSante>().HasKey(n => n.UniqueId); //définition de la clé primaire
            modelBuilder.Entity<CarnetDeSante>().Property(n => n.UniqueId)
                                                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None); // définition du mode de génération de la clé : pas de génération automatique
            //note : la colonne LastModified n'est pas touchée : utilisation des conventions EF


            //on précise qu'il y a une relation entre CarnetDeSante et Nounours
            modelBuilder.Entity<CarnetDeSante>() //l'entité CarnetDeSante...
                        .HasRequired(c => c.Owner) //a une propriété obligatoire Owner...
                        .WithRequiredDependent(n => n.Carnet); //reliée à la propriété Carnet du Owner...
            //remplace la ForeignKey

            base.OnModelCreating(modelBuilder);
        }
    }
}
