﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : CarnetDeSante.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-18
//
// ========================================================================

using System;

namespace ex_042_007_EF_CF_One_to_One_FluentAPI
{
    /// <summary>
    /// CarnetDeSante est une classe POCO, i.e. Plain Old CLR Object
    /// Elle a une relation 1-1 avec la classe Nounours via la propriété Owner.
    /// </summary>
    public class CarnetDeSante
    {
        public Guid UniqueId
        {
            get; set;
        }

        public DateTime LastModified
        {
            get; set;
        }

        public virtual Nounours Owner
        {
            get; set; 
        }

        public override string ToString()
        {
            return $"{UniqueId} : carnet de {Owner.Nom}, modifié la dernière fois le {LastModified.ToString("d")}";
        }
    }
}
