﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : MyStubDataInitializationStrategy.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-18
//
// ========================================================================

using System;
using System.Data.Entity;

namespace ex_042_007_EF_CF_One_to_One_FluentAPI
{
    /// <summary>
    /// classe personnalisée pour l'initialisation de la base :
    /// - recrée une base neuve (dérive de DropCreateDatabaseAlways
    /// - introduit des données stubbées (méthode Seed)
    /// </summary>
    class MyStubDataInitializationStrategy : DropCreateDatabaseAlways<NounoursDBEntities>
    {
        protected override void Seed(NounoursDBEntities context)
        {
            Nounours chewie = new Nounours { Nom = "Chewbacca", DateDeNaissance = new DateTime(1977, 5, 27), NbPoils = 1234567 };
            Nounours yoda = new Nounours { Nom = "Yoda", DateDeNaissance = new DateTime(1980, 5, 21), NbPoils = 3 };
            Nounours ewok = new Nounours { Nom = "Ewok", DateDeNaissance = new DateTime(1983, 5, 25), NbPoils = 3456789 };

            CarnetDeSante carnet1 = new CarnetDeSante { Owner = chewie, LastModified = DateTime.Today };
            CarnetDeSante carnet2 = new CarnetDeSante { Owner = yoda, LastModified = new DateTime(1980, 5, 21) };
            CarnetDeSante carnet3 = new CarnetDeSante { Owner = ewok, LastModified = new DateTime(1983, 5, 25) };

            chewie.Carnet = carnet1;
            yoda.Carnet = carnet2;
            ewok.Carnet = carnet3;

            context.NounoursSet.AddRange(new Nounours[] { chewie, yoda, ewok });
            context.Carnets.AddRange(new CarnetDeSante[] { carnet1, carnet2, carnet3 });

            base.Seed(context);
        }
    }
}
