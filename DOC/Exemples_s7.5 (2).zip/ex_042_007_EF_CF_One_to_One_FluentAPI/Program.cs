﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-18
//
// ========================================================================

using System;
using System.IO;
using static System.Console;

namespace ex_042_007_EF_CF_One_to_One_FluentAPI
{
    class Program
    {
        /// <summary>
        /// Cet exemple montre comment construire une relation 1-1 dans la base de données en utilisant la Fluent API.
        /// On préférera cette solution par exemple lorsque nous n'avons pas accès à la classe Model et que nous ne pouvons donc pas utiliser les conventions de nommage
        /// comme dans l'exemple précédent.
        /// 
        /// on utilise les données stubbées de MyStubDataInitializationStrategy
        /// On affiche les Nounours et les Carnets de santé.
        /// Constatez que les identifiants sont bien les mêmes à cause de la relation 1-1.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.SetData("DataDirectory", Directory.GetCurrentDirectory());

            //création du DbContext et injection de la dépendance à MyStubDataInitializationStrategy
            using (NounoursDBEntities db = new NounoursDBEntities(new MyStubDataInitializationStrategy()))
            {
                WriteLine("nounours : ");
                foreach (var n in db.NounoursSet)
                {
                    WriteLine($"\t{n}, LastModified: {n.Carnet.LastModified.ToString("d")}");
                }

                WriteLine("carnets de santé : ");
                foreach (var c in db.Carnets)
                {
                    WriteLine($"\t{c}");
                }
            }
        }
    }
}
