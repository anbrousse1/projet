﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Nounours.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-01
//
// ========================================================================

using System;

namespace ex_023_019_ReadOnlyDictionary_and_values_dll
{
    class Nounours : IEquatable<Nounours>, INounours
    {
        public int Id
        {
            get;
            private set;
        }

        public string Nom
        {
            get;
            set;
        }

        public DateTime DateDeNaissance
        {
            get;
            private set;
        }

        public int NbPoils
        {
            get;
            set;
        }

        public Nounours(int id, string nom, DateTime dateDeNaissance, int nbPoils)
        {
            Id = id;
            Nom = nom;
            DateDeNaissance = dateDeNaissance;
            NbPoils = nbPoils;
        }

        //...

        /// <summary>
        /// returns a hash code in order to use this class in hash table
        /// </summary>
        /// <returns>hash code</returns>
        public override int GetHashCode()
        {
            return (DateDeNaissance.Year * 1000 + DateDeNaissance.DayOfYear) * Nom.GetHashCode();
        }

        /// <summary>
        /// checks if the "right" object is equal to this Nounours or not
        /// </summary>
        /// <param name="right">the other object to be compared with this Nounours</param>
        /// <returns>true if equals, false if not</returns>
        public override bool Equals(object right)
        {
            //check null
            if (object.ReferenceEquals(right, null))
            {
                return false;
            }

            if (object.ReferenceEquals(this, right))
            {
                return true;
            }

            if (this.GetType() != right.GetType())
            {
                return false;
            }

            return this.Equals(right as Nounours);
        }

        /// <summary>
        /// checks if this Nounours is equal to the other Nounours
        /// </summary>
        /// <param name="other">the other Nounours to be compared with</param>
        /// <returns>true if equals</returns>
        public bool Equals(Nounours other)
        {
            return (this.Nom.Equals(other.Nom) && this.DateDeNaissance.Equals(other.DateDeNaissance));
        }

        public override string ToString()
        {
            return $"{Nom} ({DateDeNaissance.ToString("d")} - nb de poils : {NbPoils})";
        }
    }
}
