﻿// ========================================================================
//
// Copyright (C) 2013-2014 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2014-03-30
// Mise à jour   : 2016-10-02
//
// ========================================================================

using System;
using static System.Console;

namespace ex_024_005_exceptions_personnalisees
{
    /// <summary>
    /// ma classe d'exception
    /// </summary>
    class MyException : Exception
    {
        public MyException(string msg) : base(msg) { }
    }

    /// <summary>
    /// programme utilisant une exception personnalisée si les deux noms rentrés par les joueurs sont les mêmes
    /// </summary>
    class Program
    {
        static void GetPlayerNames()
        {
            WriteLine("Rentrez le nom du premier joueur");
            string player1 = ReadLine();
            WriteLine("Rentrez le nom du deuxième joueur");
            string player2 = ReadLine();

            if (player1 == player2)
            {
                throw new MyException($"Les deux joueurs s'appellent {player1}. Ils doivent avoir des noms différents");
            }
        }

        static void Main(string[] args)
        {
            try
            {
                GetPlayerNames();
            }
            catch (MyException exc)
            {
                WriteLine(exc.Message);
            }
            WriteLine("pas de jeu en fait...");
        }
    }
}
