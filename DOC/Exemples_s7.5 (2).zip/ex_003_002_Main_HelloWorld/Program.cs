﻿// ========================================================================
//
// Copyright (C) 2013-2014 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2014-03-30
// Mise à jour   : 2016-09-21
//
// ========================================================================

//Ici, nous avons besoin de using System; car la classe Console est dans l'espace de noms System.
using System;
using static System.Console;

//Ce programme affiche "Coucou le monde !" dans la console.
namespace ex_003_002_Main_HelloWorld
{
    class Program
    {
        //aucun argument
        static void Main()
        {
            //avant C#6, Console était obligatoire avant WriteLine
            Console.WriteLine("Coucou le monde !");

            //depuis C#6, Console n'est pas nécessaire si on déclare au-dessus : using static System.Console;
            WriteLine("Coucou le monde !");
        }
    }
}
