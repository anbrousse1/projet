﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Program.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-19
//
// ========================================================================

using System;
using System.IO;
using static System.Console;

namespace ex_042_008_EF_CF_One_to_Many
{
    class Program
    {
        /// <summary>
        /// Cet exemple montre comment construire une relation 1-many dans la base de données en utilisant les conventions de nommage Entity Framework.
        /// 
        /// on utilise les données stubbées de MyStubDataInitializationStrategy
        /// On affiche les Albums et les Morceaux.
        /// Constatez que les identifiants sont bien les mêmes à cause de la relation 1-many.
        /// 
        /// Si vous ouvrez la base de données (via l'explorateur d'objets SQL Server), vous pourrez constater que la table Morceaux 
        ///     contient une colonne Album_UniqueId qui permet d'assurer la relation 1-many.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.SetData("DataDirectory", Directory.GetCurrentDirectory());

            //création du DbContext et injection de la dépendance à MyStubDataInitializationStrategy
            using (AlbumDBEntities db = new AlbumDBEntities(new MyStubDataInitializationStrategy()))
            {
                WriteLine("Albums : ");
                foreach (var a in db.Albums)
                {
                    WriteLine($"\t{a.UniqueId}: {a.Titre} (sorti le : {a.DateDeSortie.ToString("d")})");
                    foreach (var m in a.Morceaux)
                    {
                        WriteLine($"\t\t{m.Titre}");
                    }
                }

                WriteLine();

                WriteLine("Morceaux :");
                foreach(var m in db.Morceaux)
                {
                    WriteLine($"\t{m.UniqueId}: {m.Titre} (album : {m.Album.Titre})");
                }

            }
        }
    }
}
