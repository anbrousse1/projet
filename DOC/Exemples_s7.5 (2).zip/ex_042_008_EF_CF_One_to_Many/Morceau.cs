﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : Morceau.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-19
//
// ========================================================================

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ex_042_008_EF_CF_One_to_Many
{
    /// <summary>
    /// Morceau est une classe POCO, i.e. Plain Old CLR Object.
    /// Elle a une relation 1-many avec la classe Morceau via la propriété Album.
    /// La clé primaire est générée lors de l'insertion en table.
    /// </summary>
    [Table("Morceaux")]
    class Morceau
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid UniqueId
        {
            get; set;
        }

        public string Titre
        {
            get; set;
        }

        public virtual Album Album
        {
            get; set; 
        }
    }
}
