﻿// ========================================================================
//
// Copyright (C) 2016-2017 MARC CHEVALDONNE
//                         marc.chevaldonne.free.fr
//
// Module        : MyStubDataInitializationStrategy.cs
// Author        : Marc Chevaldonné
// Creation date : 2016-10-19
//
// ========================================================================

using System;
using System.Data.Entity;

namespace ex_042_008_EF_CF_One_to_Many
{
    /// <summary>
    /// classe personnalisée pour l'initialisation de la base :
    /// - recrée une base neuve (dérive de DropCreateDatabaseAlways)
    /// - introduit des données stubbées (méthode Seed)
    /// </summary>
    class MyStubDataInitializationStrategy : DropCreateDatabaseAlways<AlbumDBEntities>
    {
        protected override void Seed(AlbumDBEntities context)
        {
            Album kindofblue = new Album { Titre = "Kind of Blue", DateDeSortie = new DateTime(1959, 8, 17)};
            Morceau[] kindofblueMorceaux = { new Morceau { Album = kindofblue, Titre = "So What" },
                                             new Morceau { Album = kindofblue, Titre = "Freddie Freeloader" },
                                             new Morceau { Album = kindofblue, Titre = "Blue in Green" },
                                             new Morceau { Album = kindofblue, Titre = "All Blues" },
                                             new Morceau { Album = kindofblue, Titre = "Flamenco Sketches" } };
            foreach (var m in kindofblueMorceaux) kindofblue.Morceaux.Add(m);

            Album dialogue = new Album { Titre = "Dialogue", DateDeSortie = new DateTime(1965, 9, 1) };
            Morceau[] dialogueMorceaux = { new Morceau { Album = dialogue, Titre = "Catta" },
                                             new Morceau { Album = dialogue, Titre = "Idle While" },
                                             new Morceau { Album = dialogue, Titre = "Les Noirs Marchant" },
                                             new Morceau { Album = dialogue, Titre = "Dialogue" },
                                             new Morceau { Album = dialogue, Titre = "Ghetto Lights" },
                                             new Morceau { Album = dialogue, Titre = "Jasper" } };
            foreach (var m in dialogueMorceaux) dialogue.Morceaux.Add(m);

            context.Albums.AddRange(new Album[] { kindofblue, dialogue});
            context.Morceaux.AddRange(kindofblueMorceaux);
            context.Morceaux.AddRange(dialogueMorceaux);

            base.Seed(context);
        }
    }
}
